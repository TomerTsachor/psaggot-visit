from logging import getLogger

from .constants import LOG_LEVEL


LOG = getLogger('dataclass_wizard')
LOG.setLevel(LOG_LEVEL)
